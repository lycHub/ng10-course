const BASE_URL = 'https://www.ximalaya.com/revision'
module.exports = {
  BASE_URL,
  authKey: 'xm-auth',
  account: {
    name: '张三',
    phone: '13647008979',
    password: 'angular9'
  }
}
