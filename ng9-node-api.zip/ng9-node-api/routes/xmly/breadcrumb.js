const request = require('request');
const { BASE_URL } = require('./config');

module.exports = (req, res) => {
  const categoryId = req.query.categoryId || '';
  const uri = BASE_URL + '/category/breadcrumbCategoryInfo?categoryId=' + categoryId;
  request(uri, function (error, response, body) {
    if (error) {
      res.status(500).json({
        ret: 0,
        message: '面包屑请求失败',
        data: error
      });
    } else {
      res.status(response.statusCode).json(JSON.parse(body))
    }
  });
}

