# webtask-tpl-tsnext

#### 介绍
webtask-cli typescript 模板
webtask create <projectName> tsnext